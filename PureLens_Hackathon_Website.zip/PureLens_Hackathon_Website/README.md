# PureLens Hackathon Website

A laptop-first Flask prototype with image upload and real optical image-feature extraction using Python/OpenCV.

## Run on Windows
1. Install Python 3.10+.
2. Extract this ZIP.
3. Open Command Prompt in this folder.
4. Run:
   ```bash
   py -m venv .venv
   .venv\\Scripts\\activate
   pip install -r requirements.txt
   python app.py
   ```
5. Open http://127.0.0.1:5000

## Run on macOS/Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## What works
- Premium responsive dashboard
- JPG/JPEG/PNG/WEBP upload and drag-and-drop
- OpenCV extraction of mean brightness, contrast, colour saturation and edge density
- Results display in the browser
- Uploaded image is deleted after analysis

## Scientific limitation
This is a working **optical image-feature extraction prototype**, not a validated milk-adulteration classifier. It does not determine whether milk is pure/adulterated or identify adulterants. A real classifier requires controlled image capture, many samples labelled using reliable laboratory tests, model training, independent validation and uncertainty reporting. Do not use this demo for food-safety decisions.

## Hackathon presentation flow
1. Introduce the problem and why visual inspection is insufficient.
2. Show the dashboard and explain the optical capture setup.
3. Upload an example sample image.
4. Explain the extracted image features.
5. Present model training and lab validation as the next development stage.
6. Be transparent that this prototype extracts features but does not yet issue an adulteration verdict.

For public deployment, disable Flask debug mode and use a production WSGI server with appropriate security controls.
